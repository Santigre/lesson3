﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MyChallenge3
{
    public partial class defualt : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void okButton_Click(object sender, EventArgs e)
        {
            if (pencilButton.Checked)
            {
                resultImage.ImageUrl = "pencil.png";
                resultLabel1.Text = "You picked pencil"; 
            }

            else if (penButton.Checked)
            {
                resultImage.ImageUrl = "pen.png";
                resultLabel1.Text = "You picked pen";
            }

            else if (phoneButton.Checked)
            {
                resultImage.ImageUrl = "phone.png";
                resultLabel1.Text = "You picked phone";
            }

            else if (tabletButton.Checked)
            {
                resultImage.ImageUrl = "tablet.png";
                resultLabel1.Text = "You picked tablet";
            }

            else
            {
                resultLabel1.Text = "You haven't picked one yet";
            }
        }
    }
}